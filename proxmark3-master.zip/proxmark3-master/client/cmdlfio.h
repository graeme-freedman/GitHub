// Low frequency Kantech commands
//-----------------------------------------------------------------------------

#ifndef CMDLFIO_H__
#define CMDLFIO_H__

extern int CmdLFIO(const char *Cmd);
extern int CmdFSKdemodIO(const char *Cmd);
extern int CmdIOReadFSK(const char *Cmd);

#endif
